# MASKORA GitHub Pages

## Pasos rápidos para subirlo a GitHub Pages

1. Entra a GitHub y crea un repositorio nuevo, por ejemplo: `maskora-lab`
2. Sube el archivo `index.html` a la raíz del repositorio.
3. Ve a **Settings** del repositorio.
4. En el menú lateral entra a **Pages**.
5. En **Build and deployment** selecciona:
   - **Source:** Deploy from a branch
   - **Branch:** `main`
   - **Folder:** `/ (root)`
6. Guarda los cambios.
7. Espera 1 o 2 minutos y GitHub te dará una URL parecida a:
   `https://TUUSUARIO.github.io/maskora-lab/`

## Recomendación para iPhone
Ábrelo en Safari desde esa URL y usa **Compartir > Agregar a pantalla de inicio**.

## Archivo principal
- `index.html`
